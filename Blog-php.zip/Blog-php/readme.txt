thanks for watching 
Complete Responsive Blog Website using PHP_MySQL _ Free Source Code Download

login to admin
admin
123456